fx_version 'cerulean'
game 'gta5'

author 'Storm Systems'
description 'City Info / Starter Pack'
version '1.0.0'

client_scripts {
    'client.lua'
}

shared_scripts {
    '@ox_lib/init.lua'
}
dependency 'storm_starterpack'
dependency 'ox_target'
dependency 'ox_lib'
dependency 'ox_inventory'